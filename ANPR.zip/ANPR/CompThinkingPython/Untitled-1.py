def search_algorithm(list, target):
    n=0
    for number in list:
        if n<len(list):
           if target==list[n]:
            print("Target found at:",n)
           else :
                n=n+1
            
            
           if n>=len(list):
            print("target not found")

        

data=[51, 16, 18, 120, 145, 13]
target1=13
target2=30
search_algorithm(data, target1)
search_algorithm(data, target2)
