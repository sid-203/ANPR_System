def list_maker():
    list=[]
    number_count=int(input("how many numbers in your list: "))
    i=0
    while i<number_count:
        number=input("Input number: ")
        list.append(number)
        i+=1
    print(list)

list_maker()