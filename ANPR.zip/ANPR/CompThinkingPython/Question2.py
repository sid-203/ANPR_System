num_1=input("Input first number: ")
num_2=input("Input second number: ")
num_3= input("Input third number: ")

Max_number=num_1

if num_1<num_2:
    Max_number=num_2
    if num_2<num_3:
        Max_number=num_3
elif num_1<num_3:
    Max_number=num_3

print("Largest number is: ", Max_number)