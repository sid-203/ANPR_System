def Selection_Sort(array, size):
    sorted=[]
    unsorted=array
    i=1
    while i<=size:
        min=unsorted[0]
        i+=1
        for number in unsorted:
            if number<min:
                min=number
        unsorted.remove(min)
        sorted.append(min)
    print(sorted)


def list_maker():
    array=[]
    number_count=int(input("how many numbers in your list: "))
    i=0
    while i<number_count:
        number=input("Input number: ")
        array.append(number)
        i+=1
    return array


data=list_maker()
length=len(data)
Selection_Sort(data, length)