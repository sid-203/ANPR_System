def prime_numbers(arr):
    sum=0
    for item in arr:
        if item >1:
            i=0
            for i in range(2, item-1):
                if (item%i)==0:
                    return False
            else:
                sum+=item
                print(sum)
            print("sum is: ", sum)

list=[1, 2, 3, 5, 6, 7, 8, 10, 12, 13, 15]
prime_numbers(list)