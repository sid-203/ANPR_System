def list_cheker(list):
    if list==sorted(list):
        print("list is sorted")
    else:
        print("list is not sorted")


test=[23, 45, 62, 27]

list_cheker(test)