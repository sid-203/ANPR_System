def test(array):
    sorted=array
    print(sorted)

array=[0, 5, 6, 8]
test(array)