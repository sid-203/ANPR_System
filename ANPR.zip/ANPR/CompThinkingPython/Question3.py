list = [7, 3, 8, 5, 4, 2, 19, 11,]
even_number_count=0
for number in list:
    if number%2==0:
        even_number_count=even_number_count+1
print(even_number_count)