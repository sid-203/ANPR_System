num_list=[]
num1=input("Input first number: ")
num2=input("Input second number: ")
num3=input("Input third number: ")
num_list.insert(0, num1)
num_list.insert(1, num2)
num_list.insert(2, num3)
print("Largest number is: ", max(num_list))
print("Smallest number is: ", min(num_list))