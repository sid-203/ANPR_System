def binary_search(array, size, target):
    list=sorted(array)
    if list[size/2]==target:
        return 1
    n=0
    if list[size/2]>target:
        while n<size/2:
            if list[n]==target:
                return 2
            n+1
    else:
        