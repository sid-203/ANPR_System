R1=3*4
R2=6*4
R3=3*4
K=2*3
B1=1*2
B2=3*4
LR=8*5
SR=3*4
Surface=(R1+R2+R3+K+B1+B2+LR)-SR
print("The area is: ", Surface, " m2")