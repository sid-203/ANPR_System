def min_function(array):
    min_number=array[0]
    for number in array:
        if number<min_number:
            min_number=number
    print("smallest number is: ", min_number)


test_list=[51, 16, 18, 120, 145, 13]

min_function(test_list)

print("verification: ", min(test_list))