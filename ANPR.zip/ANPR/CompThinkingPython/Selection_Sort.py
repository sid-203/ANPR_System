def Selection_Sort(array, size):
    sorted=[]
    unsorted=array
    i=1
    while i<=size:
        min=unsorted[0]
        i+=1
        for number in unsorted:
            if number<min:
                min=number
        unsorted.remove(min)
        sorted.append(min)
    print(sorted)

array=[51, 16, 18, 120, 145, 13]
size=len(array)
Selection_Sort(array, size)