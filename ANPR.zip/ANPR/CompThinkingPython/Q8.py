def search_algorithm(list, target):
    for number in list:
        if number==target:
            return 1
    return 2

data=[51, 16, 18, 120, 145, 13]
target1=5
a=search_algorithm(data, target1)
if a==1:
    print("target found at: ", data.index(target1))
else:
    print("target not found")