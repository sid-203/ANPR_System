def binary_search(array, size, target):
    list=sorted(array)
    list_a=list[:len(list)//2]
    list_b=list[len(list)//2:]

    if list[size/2]<target:
        for number in list_b:
            if number==target:
                return 2
    elif list[size/2]>target:
        for number in list_a:
            if number==target:
                return 3
    if list[size/2]==target:
        return 1
    else:
        return 4

test=[51, 16, 18, 120, 145, 13]
target1=13
result=binary_search(test, 6, target1)
if result==1:
    print("number found at: ", test.index(target1))
elif result==2:
    print("number found at: ", test.index(target1))
elif result==3:
    print("number found at: ", test.index(target1))
else:
    print("number not found")